def to_list(variable: str) -> list:
    return [variable]


def to_tuple(variable: str) -> tuple:
    return (variable, )
