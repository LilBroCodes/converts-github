def to_list(variable: int) -> list:
    return [variable]


def to_tuple(variable: int) -> tuple:
    return (variable, )
